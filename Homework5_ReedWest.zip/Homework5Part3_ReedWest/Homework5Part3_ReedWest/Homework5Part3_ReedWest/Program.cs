﻿
using System.IO;
using System;
using System.Collections.Generic;

namespace Homework5Part3_ReedWest
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] sentences = File.ReadAllLines("Jane Eyre.txt");
            
            Dictionary<string, int> wordCount = new Dictionary<string, int>();
            bool foundBeginningOfBook = false;
            foreach (string line in sentences)
            {

                if (line.Contains("CHAPTER I") == true)
                {
                    foundBeginningOfBook = true;
                }
                if (foundBeginningOfBook == false &&
                    string.IsNullOrWhiteSpace(line) == true)
                {
                    continue;
                }
                if (line.Contains("***END OF THE PROJECT GUTENBERG EBOOK JANE EYRE***") == true) ;
                string[] words = line.Split(" ");
                foreach (string word in words)
                {
                    char[] punctuation = { ',', '/', '.', '?', ':', '$', ';', '"' };
                    string current = word.ToLower().Trim(punctuation);


                    if (wordCount.ContainsKey(current) == false)
                    {
                        wordCount.Add(word.ToLower(), 0);

                    }

                    wordCount[current] = wordCount[current] + 1;

                }

                Console.WriteLine("\nJane Eyre Dictionary");
                Console.WriteLine($"{"Word".PadRight(25, ' ')}\t\t\tCount");

            }
            foreach (string word in wordCount.Keys)
                {
                Console.WriteLine($"{word}\t\t\t{wordCount[word].ToString("N0")}");
                }
            Console.WriteLine("Do you want to search for a word?");
            string answer = Console.ReadLine();
            if (wordCount.ContainsKey(answer)== true)
            {
                Console.WriteLine($"{answer} is found {wordCount[answer]:N0})");
            }

            }
        }
    }

